//LCD kijelzo mukodesenek ellenorzese

//PA0 - az LCD kijelzo RS (Reset / Torlo) laba (4 lab)
//Fold - R/~W (Read / ~Write) csak irni tudunk az LCD kijelzobe(5 lab)
//PA1 - E (Enable / Engedelyezo) lab (6 lab)

//PA2-PA5 - az LCD kijelzo DB4-DB7 adatbemenetei

/******************************************************/

#include <avr/io.h> //Az I/O konyvtar
#include <util/delay.h> //A kesleltetes-beallitas konyvtar
#include <avr/sleep.h>
#include "lcd.h"


//-----------A foprogram------------
int main(void) //A foprogram kezdete
{
  DDRA = 0xFF; //A PORT A kimenet
  PORTA = 0xC0; //A PORT A (PA0-PA5) kimeneteit 0-ra allitjuk, a (PA6-PA7) - 1-re
  
  lcd4_init(); //Az LCD kijelzo inicializalasa (4 bit, 2 sor)

//A szoveg kezdete  
  lcd4_dat('H');
  lcd4_dat('e');
  lcd4_dat('l');
  lcd4_dat('l');
  lcd4_dat('o');
  lcd4_dat(',');
  lcd4_dat(' ');
  lcd4_dat('v');
  lcd4_dat('i');
  lcd4_dat('l');
  lcd4_dat('a');
  lcd4_dat('g');
  lcd4_dat('!');
//A szoveg vege

  
  lcd4_com(0xC0); //Beiras az LCD kijelzo masodik soraba
  
  lcd4_dat(0x48);
  lcd4_dat('e');
  lcd4_dat('l');
  lcd4_dat('l');
  lcd4_dat('o');
  lcd4_dat(',');
  lcd4_dat(' ');
  lcd4_dat('v');
  lcd4_dat('i');
  lcd4_dat('l');
  lcd4_dat('a');
  lcd4_dat('g');
  lcd4_dat('!');

  sleep_cpu(); //A MPU "elaltatasa"
  return(0); //A "main" program sikeres befejezese 

}
